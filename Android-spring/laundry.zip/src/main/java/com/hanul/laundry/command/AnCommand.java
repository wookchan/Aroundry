package com.hanul.laundry.command;

import org.springframework.ui.Model;

public interface AnCommand {
	public void execute(Model model);
}
