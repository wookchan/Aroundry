package com.hanul.laundry.command;

import org.springframework.ui.Model;

public interface kkbAnCommand {
	public void execute(Model model);
}
