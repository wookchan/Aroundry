package com.hanul.laundry.dto;

public class khjRecentDTO {
	String recent;

	public khjRecentDTO(String recent) {
		super();
		this.recent = recent;
	}

	public String getRecent() {
		return recent;
	}

	public void setRecent(String recent) {
		this.recent = recent;
	}
	
	

}
